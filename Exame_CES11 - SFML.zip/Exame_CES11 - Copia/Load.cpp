#include "Load.h"
#include "Mapa.h"

LoadSave::LoadSave()
{
    isPressed = Select = false;
    
    font.loadFromFile("resources/fonts/arial.ttf");

    back.loadFromFile("resources/textures/Background.jpg");
    Background.setTexture(back);

    std::vector<std::string> String_Text{ "Slot 1", "Slot 2", "Slot 3" };
    std::vector<sf::Vector2f> String_Pos{ {400,200},{400, 300}, {400,400} };
    const int String_Size = 70;

    for (int i = 0; i < Max_load_menu; i++) {
        loadMenu[i].setFont(font);
        loadMenu[i].setFillColor(sf::Color::White);
        loadMenu[i].setString(String_Text[i]);
        loadMenu[i].setCharacterSize(String_Size);
        loadMenu[i].setPosition(String_Pos[i]);
    }

    LoadMenuSelected = 0;
}

void LoadSave::draw(sf::RenderWindow& window)
{
    window.clear();
    window.draw(Background);
    for (const auto& i : loadMenu) window.draw(i);
    window.display();
}

void LoadSave::MoveUp(bool& isPressed)
{
    if (LoadMenuSelected >= 0) {
        loadMenu[LoadMenuSelected].setFillColor(sf::Color::White);
        --LoadMenuSelected;
        if (LoadMenuSelected == -1) LoadMenuSelected = 2;
        isPressed = true;
        loadMenu[LoadMenuSelected].setFillColor(sf::Color::Blue);
        isPressed = false;
        Select = false;
    }
}

void LoadSave::MoveDown(bool& isPressed)
{
    if (LoadMenuSelected < 3) {
        loadMenu[LoadMenuSelected].setFillColor(sf::Color::White);
        ++LoadMenuSelected;
        if (LoadMenuSelected == 3) LoadMenuSelected = 0;
        isPressed = true;
        loadMenu[LoadMenuSelected].setFillColor(sf::Color::Blue);
        isPressed = false;
        Select = false;
    }
}

void LoadSave::Loop(sf::RenderWindow& window)
{
    Mapa map;
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) window.close();
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && !isPressed) MoveUp(isPressed);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && !isPressed) MoveDown(isPressed);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter) && !Select) {
                Select = true;
            }
        }
        draw(window);
    }

}