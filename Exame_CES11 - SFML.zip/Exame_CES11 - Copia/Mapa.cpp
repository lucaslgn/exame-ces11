#include "Mapa.h"
#include "PauseMenu.h"
#include <iostream>

Mapa::Mapa()
{
	texMap.loadFromFile("resources/textures/Map.png");
	Map.setTexture(texMap);

	isPressed = false;
}

void Mapa::Move()
{

}
void Mapa::Loop(sf::RenderWindow& window)
{
	PauseMenu pause;

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape) && !isPressed) {
				isPressed = true;
				std::cout << "PAUSE\n";
				if (pause.Loop(window)) return;
				isPressed = false;
			}
		}
		Draw(window);
	}
}

void Mapa::Draw(sf::RenderWindow& window)
{
	window.clear();
	window.draw(Map);
	window.display();
}

