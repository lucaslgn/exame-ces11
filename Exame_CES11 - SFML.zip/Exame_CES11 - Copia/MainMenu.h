#pragma once
#include<SFML/Graphics.hpp>

const int Max_main_menu = 3;

class MainMenu {
private:
    int MainMenuSelected;
    bool isPressed, Select;

    sf::Texture back;
    sf::Sprite Background;
    sf::Font font;
    sf::Text mainMenu[Max_main_menu];

public:
    MainMenu(sf::RenderWindow&);

    void Loop(sf::RenderWindow&);
    void draw(sf::RenderWindow&);
    void MoveUp(bool&);
    void MoveDown(bool&);

    ~MainMenu();
};

