#include "PauseMenu.h"

PauseMenu::PauseMenu() {
    isPressed = Select = false;
    font.loadFromFile("resources/fonts/arial.ttf");

    back.loadFromFile("resources/textures/Pause.jpg");
    Background.setTexture(back);

    std::vector<std::string> String_Text{ "Save Game and Exit", "Exit" };
    std::vector<sf::Vector2f> String_Pos{ {400,200},{400, 300}};
    const int String_Size = 70;

    for (int i = 0; i < Max_pause_menu; i++) {
        pauseMenu[i].setFont(font);
        pauseMenu[i].setFillColor(sf::Color::White);
        pauseMenu[i].setString(String_Text[i]);
        pauseMenu[i].setCharacterSize(String_Size);
        pauseMenu[i].setPosition(String_Pos[i]);
    }

    PauseMenuSelected = 0;
}
void PauseMenu::Draw(sf::RenderWindow& window)
{
    window.clear();
    window.draw(Background);
    for (const auto& i : pauseMenu) window.draw(i);
    window.display();
}

void PauseMenu::MoveUp(bool& isPressed)
{
    if (PauseMenuSelected >= 0) {
        pauseMenu[PauseMenuSelected].setFillColor(sf::Color::White);
        --PauseMenuSelected;
        if (PauseMenuSelected == -1) PauseMenuSelected = 1;
        isPressed = true;
        pauseMenu[PauseMenuSelected].setFillColor(sf::Color::Blue);
        isPressed = false;
        Select = false;
    }
}

void PauseMenu::MoveDown(bool& isPressed)
{
    if (PauseMenuSelected < 2) {
        pauseMenu[PauseMenuSelected].setFillColor(sf::Color::White);
        ++PauseMenuSelected;
        if (PauseMenuSelected == 3) PauseMenuSelected = 0;
        isPressed = true;
        pauseMenu[PauseMenuSelected].setFillColor(sf::Color::Blue);
        isPressed = false;
        Select = false;
    }
}

bool PauseMenu::Loop(sf::RenderWindow& window)
{
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) window.close();
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && !isPressed) MoveUp(isPressed);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && !isPressed) MoveDown(isPressed);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape) && !isPressed) {
                isPressed = true;
                isPressed = false;
                return false;
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter) && !Select) {
                Select = true;
                if (PauseMenuSelected == 0) {
                    //Configurar a parte de salvar a posi��o
                    return true;
                }
                else if (PauseMenuSelected == 1) {
                    return true;
                }
            }
        }
        Draw(window);
    }

}