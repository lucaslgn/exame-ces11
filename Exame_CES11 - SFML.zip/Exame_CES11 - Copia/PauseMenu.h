#pragma once
#include <SFML/Graphics.hpp>

const int Max_pause_menu = 2;

class PauseMenu {
    int PauseMenuSelected;
    bool isPressed, Select;

    sf::Texture back;
    sf::Sprite Background;
    sf::Font font;
    sf::Text pauseMenu[Max_pause_menu];
public:
	PauseMenu();
    void Draw(sf::RenderWindow&);
    void MoveUp(bool&);
    void MoveDown(bool&);
    bool Loop(sf::RenderWindow&);
};