#pragma once
#include <SFML/Graphics.hpp>
//#include "Person.h"

class Mapa {
	bool isPressed, Select;
	
	//Person Steve;
	sf::Texture texMap;
	sf::Sprite Map;

public:
	Mapa();

	void getPosition();
	void Move();
	void Loop(sf::RenderWindow&);
	void Draw(sf::RenderWindow&);
	void Pause();
};

