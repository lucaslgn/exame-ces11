#include "Game.h"
#include "MainMenu.h"
#include "Mapa.h"

Game::Game()
{
	window.create(sf::VideoMode(1280, 720), "Exame", sf::Style::Default);
	window.setFramerateLimit(60);
	window.setPosition(sf::Vector2i(0, 0));
}

void Game::run()
{
	MainMenu mainMenu(window);
	mainMenu.Loop(window);
}

Game::~Game()
{
}
