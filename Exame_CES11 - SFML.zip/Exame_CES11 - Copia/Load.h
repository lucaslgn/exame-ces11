#pragma once
#include <SFML/Graphics.hpp>

const int Max_load_menu = 3;

class LoadSave {
    int LoadMenuSelected;
    bool isPressed, Select;

    sf::Texture back;
    sf::Sprite Background;
    sf::Font font;
    sf::Text loadMenu[Max_load_menu];

public:
    LoadSave();

    void Loop(sf::RenderWindow&);
    void draw(sf::RenderWindow&);
    void MoveUp(bool&);
    void MoveDown(bool&);
};