#include "MainMenu.h"
#include "Mapa.h"
#include "Load.h"

MainMenu::MainMenu(sf::RenderWindow& window)
{
    isPressed = Select = false;
    font.loadFromFile("resources/fonts/arial.ttf");
    
    back.loadFromFile("resources/textures/Background.png");
    Background.setTexture(back);

    std::vector<std::string> String_Text{ "New Game", "Continue", "Exit" };
    std::vector<sf::Vector2f> String_Pos{ {400,200},{400, 300}, {400,400} };
    const int String_Size = 70;

    for (int i = 0; i < Max_main_menu; i++) {
        mainMenu[i].setFont(font);
        mainMenu[i].setFillColor(sf::Color::White);
        mainMenu[i].setString(String_Text[i]);
        mainMenu[i].setCharacterSize(String_Size);
        mainMenu[i].setPosition(String_Pos[i]);
    }

    MainMenuSelected = 0;

}

void MainMenu::Loop(sf::RenderWindow& window)
{
   Mapa map;
   LoadSave save;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) window.close();
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && !isPressed) MoveUp(isPressed);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && !isPressed) MoveDown(isPressed);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter) && !Select) {
                Select = true;
                if (MainMenuSelected == 0) map.Loop(window);
                else if (MainMenuSelected == 1) save.Loop(window);
                else if(MainMenuSelected == 2) window.close();
            }
        }
        draw(window);
    }

}

void MainMenu::draw(sf::RenderWindow& window)
{
    window.clear();
    window.draw(Background);
    for (const auto& i : mainMenu) window.draw(i);
    window.display();
}

void MainMenu::MoveUp(bool& isPressed)
{
    if (MainMenuSelected >= 0) {
        mainMenu[MainMenuSelected].setFillColor(sf::Color::White);
        --MainMenuSelected;
        if (MainMenuSelected == -1) MainMenuSelected = 2;
        isPressed = true;
        mainMenu[MainMenuSelected].setFillColor(sf::Color::Blue);
        isPressed = false;
        Select = false;
    }
}

void MainMenu::MoveDown(bool& isPressed)
{
    if (MainMenuSelected < 3) {
        mainMenu[MainMenuSelected].setFillColor(sf::Color::White);
        ++MainMenuSelected;
        if (MainMenuSelected == 3) MainMenuSelected = 0;
        isPressed = true;
        mainMenu[MainMenuSelected].setFillColor(sf::Color::Blue);
        isPressed = false;
        Select = false;
    }
}

MainMenu::~MainMenu()
{
}
